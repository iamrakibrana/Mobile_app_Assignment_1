package com.example.actionbutton;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
